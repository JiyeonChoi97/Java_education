package juice;

public class Apple {

}
