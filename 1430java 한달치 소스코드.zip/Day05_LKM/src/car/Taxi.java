package car;

public class Taxi {

}
