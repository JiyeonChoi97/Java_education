
package car;

public class Bus {

}
