
public class MainClass {

//	//피자빵
//	static String name = "피자빵";
//	static int price = 500;
//	static void info() {
//		System.out.println("이름: " + name);
//		System.out.println("가격: " + price);
//	}
//	
//	//초코케이크
//	static String name2 = "초코케이크";
//	static int price2 = 1500;
//	static void info2() {
//		System.out.println("이름: " + name2);
//		System.out.println("가격: " + price2);
//	}
	
	
	
	
	public static void main(String[] args) {
		
		/*
		 - 객체를 생성하지 않았을 때의 예시를 확인하고
		  설계용 클래스를 생성하여 속성과 기능을 선언하고
		  MainClass에서 피자빵, 초코케이크의 
		  기능을 사용해 보세요.
		  
		 - 클래스의 이름은 Bread로 통일하겠습니다.
		 */
		
		Bread pizza = new Bread("피자빵", 500);
		pizza.info();
		
		Bread choco = new Bread();
		choco.name = "초코케이크";
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
