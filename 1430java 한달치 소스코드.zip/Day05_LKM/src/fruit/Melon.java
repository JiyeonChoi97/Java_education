package fruit;

public class Melon {

}
