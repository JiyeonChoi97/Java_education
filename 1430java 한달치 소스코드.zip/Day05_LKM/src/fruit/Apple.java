
/*
 - 클래스들을 묶음으로 관리하려면 패키지 선언을 해야합니다.
 - 패키지 선언은 반드시 코드의 최상단부에 위치해야 합니다.
 */
package fruit;

public class Apple {

}
