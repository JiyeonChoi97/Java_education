package reference;

public class User {
	
	String pw;
	
	User(String uPw) {
		pw = uPw;
	}
	
	

}
