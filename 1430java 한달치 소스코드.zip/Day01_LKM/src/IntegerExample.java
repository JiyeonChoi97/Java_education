
public class IntegerExample {

	public static void main(String[] args) {
		
		//리터럴: 변수에 대입되기 전의 상수. 정수 리터럴의 기본 타입은 int.
		
		byte a = 127;
		short b = 32767;
//		int c = 2147483648; (out of range)
		long d = 2147483648L;
		
		
		
		
		
		
		
		
		
		

	}

}
