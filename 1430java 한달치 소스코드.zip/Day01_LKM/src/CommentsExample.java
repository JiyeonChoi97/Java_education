
public class CommentsExample {

	public static void main(String[] args) {

		//이 소스코드는 주석에 대한 설명을 달아놓은 코드입니다.

		/*
	 	# main함수(메서드)는 프로그램을 실행 시 자동으로 작동하는
		함수이며, 반드시 필요한 함수입니다.

		# 자바코드를 해석하여 실행시키는 자바 가상 머신(JVM)은
		 프로그램을 실행 시 자동으로 main함수를 불러서 내부의 코드를
		 실행시킵니다.
		 */

		// sysout + Ctrl + spacebar: 빠른 출력 함수 생성.
		System.out.println("안녕하세요~!");
		System.out.println("반갑습니다!");
		System.out.println("안녕히 가세요~");
		//실행 단축키는 Ctrl + F11
		//		빠른 주석 처리: Ctrl + /



	}

}




