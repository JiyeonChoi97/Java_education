
public class BooleanExample {

	public static void main(String[] args) {
		
		boolean b1 = true;
		boolean b2 = false;
		
//		boolean b3 = True; (x)
//		boolean b4 = False; (x)
//		boolean b5 = 0; (x)
//		boolean b6 = "논리형 타입"; (x)

	}

}
