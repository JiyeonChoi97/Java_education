
public class FloatExample {

	public static void main(String[] args) {
		
		//실수 리터럴의 기본 타입은 double입니다.
		float f1 = 7.12345f;
		double d1 = 7.12345;
		
		System.out.println(f1);
		System.out.println(d1);
		
		System.out.println("------------------------------------");
		
		float f2 = 1.234567891234f;
		double d2 = 1.234567891234;
		System.out.println(f2);
		System.out.println(d2);
		
	}

}












