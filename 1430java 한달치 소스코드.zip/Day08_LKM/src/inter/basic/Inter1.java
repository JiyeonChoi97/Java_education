package inter.basic;

public interface Inter1 extends Inter {
	
	//인터페이스는 변수를 선언하면 자동으로 상수 취급합니다.
	double INCH = 2.54;
	
	//인터페이스에서 메서드를 선언하면 자동으로 추상 메서드 취급합니다.
	void method1();
	

}
