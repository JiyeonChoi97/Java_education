package inter.basic;

public interface Inter {

}
