package inter.basic;

public class ImplClass3 implements Inter2 {

	@Override
	public void method2() {}

}
