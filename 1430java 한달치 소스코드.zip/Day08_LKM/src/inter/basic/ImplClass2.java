package inter.basic;

public class ImplClass2 implements Inter1 {

	@Override
	public void method1() {}

}
