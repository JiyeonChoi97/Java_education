package poly.param;

public class MainClass {

	public static void main(String[] args) {

		Driver kim = new Driver();
		Car c = kim.buyCar("소나타");
		c.run();
		
		Sonata s = (Sonata)c;
		s.enterMembership();
		c.run();
		c.run();
		
		System.out.println("----------------------------");
		
		CarShop shop = new CarShop();
		
		shop.carPrice(c);
		shop.carPrice(new K5());
		shop.carPrice(kim.buyCar("말리부"));
		
		
		
		
		
		
		
		
		
		
		
	}

}
