package poly.param;

public class Sonata extends Car {

	@Override
	public void run() {
		System.out.println("소나타가 달립니다~");
	}
	
	public void enterMembership() {
		System.out.println("멤버쉽에 가입합니다.");
	}
	
	

}
