package poly.instanceof_;

public class Parent {

}
