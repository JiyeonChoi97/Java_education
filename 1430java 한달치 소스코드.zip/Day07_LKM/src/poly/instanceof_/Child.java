package poly.instanceof_;

public class Child extends Parent {

}
