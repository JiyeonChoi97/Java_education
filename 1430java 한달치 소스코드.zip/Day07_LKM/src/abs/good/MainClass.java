package abs.good;

public class MainClass {

	public static void main(String[] args) {
		
//		HeadStore h = new HeadStore(); (x)
		HeadStore s = new Store();
		s.orderApple();
		s.orderBanana();
		s.orderMelon();
		s.orderWaterMelon();
		
		
		
		
		
		
		
		
		
		
		

	}

}
