package abs.bad;

//쥬스 프랜차이즈 본사
public class HeadStore {
	
	public void orderApple() {
		System.out.println("0원입니다. 가게에서 가격을 알아서 정해주세요.");
	}
	
	public void orderBanana() {
		System.out.println("0원입니다. 가게에서 가격을 알아서 정해주세요.");
	}
	
	public void orderMelon() {
		System.out.println("0원입니다. 가게에서 가격을 알아서 정해주세요.");
	}
	
	
	
	
	
	
	
	
	

}
