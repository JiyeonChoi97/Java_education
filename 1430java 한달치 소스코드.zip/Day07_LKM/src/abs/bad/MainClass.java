package abs.bad;

public class MainClass {

	public static void main(String[] args) {
		
		HeadStore s = new Store();
		
		s.orderApple();
		s.orderBanana();
		s.orderMelon();
		
		
		
		
		
		
		
		
		

	}

}
