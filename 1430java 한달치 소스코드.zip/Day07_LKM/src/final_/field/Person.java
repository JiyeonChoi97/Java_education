package final_.field;

public class Person {

	public final String nation = "대한민국";
	public final String name;
	public int age;
	
	public Person(String name) {
		this.name = name;
	}
	
	
	
}
