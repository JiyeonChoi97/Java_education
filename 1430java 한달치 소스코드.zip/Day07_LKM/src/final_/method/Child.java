package final_.method;

public class Child extends Parent {

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		super.method1();
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		super.method2();
	}

//	public void method3() {
//		System.out.println("메서드 재정의~");
//	} final 메서드는 오버라이딩을 제한합니다.
	
	
	
	
	
	
	
	
	
	
	
	
}
