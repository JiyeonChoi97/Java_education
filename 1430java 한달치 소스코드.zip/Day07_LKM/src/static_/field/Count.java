package static_.field;

public class Count {
	
	//인스턴스 필드
	public int a;
	
	//정적 필드
	public static int b;

}
