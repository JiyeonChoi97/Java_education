
public class AssignmentOperator {

	public static void main(String[] args) {
		
		/*
		 # 대입 연산자 (=, +=, -=, *= ....)
		 */
		
		int a = 5, b = 5;
		
		a += 3; //a = a + 3
		b =+ 3; //b = +3
		System.out.println(a);
		System.out.println(b);
		
		System.out.println("---------------------------");
		
		a -= 4;
		System.out.println(a);
		
		a *= 6;
		System.out.println(a);
		
		a /= 5;
		System.out.println(a);
		
		a %= 3;
		System.out.println(a);
		
		
		
		
		
		
		

	}

}
