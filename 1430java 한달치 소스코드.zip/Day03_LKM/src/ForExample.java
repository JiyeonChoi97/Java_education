
public class ForExample {

	public static void main(String[] args) {
		
		//1~10까지의 누적합을 구하는 로직 (while)
//		int total = 0;
//		int n = 1;
//		while(n <= 10) {
//			total += n;
//			n++;
//		}
		
		//1~10까지의 누적합을 구하는 로직(for)
		int total = 0;
		for(int i = 1; i<=10; i++) {
			total += i;
		}
		
		//48~150사이의 정수 중 8의 배수를 가로로 출력(for)
		for(int i=48; i<=150; i+=8) {
			System.out.print(i + " ");
		}
		System.out.println();
		
		//1~30000까지의 정수 중 258의 배수의 갯수를 구하여 출력.
		
		int count = 0;
		for(int i=1; i<=30000; i++) {
			if(i % 258 == 0) {
				count++;
			}
		}
		System.out.println("258의 배수의 갯수: " + count + "개");
		
		
		
		
		
		
		
		
		

	}

}
