import java.util.Scanner;

public class LoopNesting2 {

	public static void main(String[] args) {
		
		/*
		 - 정수를 하나 입력받아서, 1부터 해당 정수까지의 
		  모든 소수를 판별하여 가로로 출력 후 
		  소수들의 누적합을 도출해 내야 합니다. 
		  
		 ex)
		 입력한 정수: 12 -> 2, 3, 5, 7, 11
		 모든 소수의 누적합: 28
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("정수: ");
		int num = sc.nextInt();
		
		int total = 0;
		
		System.out.print("소수: ");
		for(int i=1; i<=num; i++) {
			int count = 0;
			for(int j=1; j<=i; j++) {
				if(i % j == 0) {
					count++;
				}
			}
			if(count == 2) {
				System.out.print(i + " ");
				total += i;
			}	
		}
		
		System.out.println("\n입력받은 수 까지의 소수의 총 합: " + total);
		
		
		
		
		
		
		
		
		
		
		

	}

}
