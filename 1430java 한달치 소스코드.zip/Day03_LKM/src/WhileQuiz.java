import java.util.Scanner;

public class WhileQuiz {

	public static void main(String[] args) {
		
		/*
		 - 정수를 2개 (x, y)입력받아서 x부터 y까지의 
		  누적 합계를 while을 사용해서 구하는 코드를 작성하세요.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("정수1: ");
		int num1 = sc.nextInt();
		System.out.print("정수2: ");
		int num2 = sc.nextInt();
		
		if(num1 > num2) {
			int temp = num1;
			num1 = num2;
			num2 = temp;
		}
		
		int total = 0;
		int n = num1;
		
		while(n <= num2) {
			total += n;
			n++;
		}
		System.out.printf("%d부터 %d까지의 누적합: %d"
				, num1, num2, total);
		
		
		
		
		
		
		
		
		

	}

}
