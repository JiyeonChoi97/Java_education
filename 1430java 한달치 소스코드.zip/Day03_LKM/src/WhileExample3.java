import java.util.Scanner;

public class WhileExample3 {

	public static void main(String[] args) {
		
		/*
		 - 정수를 1개 입력받아서 해당 정수가 소수 (prime number)
		 인지의 여부를 판단하는 로직.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("정수를 입력하세요: ");
		int num = sc.nextInt();
		
		int i = 2;
		int count = 0; //나누어 떨어지는 횟수를 담을 변수.
		
		while(i <= num) {
			if(num % i == 0) {
				count++;
			}
			i++;
		}
		
		if(count == 1) {
			System.out.println(num + "은 소수입니다.");
		} else {
			System.out.println(num + "은 소수가 아닙니다.");
		}
		
		System.out.println("-------------------------------");
		
		int j = 2;
		
		while(num % j != 0) {
			j++;
		}
		
		if(num == j) {
			System.out.println(num + "은 소수입니다.");
		} else {
			System.out.println(num + "은 소수가 아닙니다.");
		}
		
		
		
		
		
		
		
		
		

	}

}
