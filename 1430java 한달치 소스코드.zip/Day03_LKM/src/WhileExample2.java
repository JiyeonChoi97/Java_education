
public class WhileExample2 {

	public static void main(String[] args) {
		
		//48 ~ 150사이의 정수 중 8의 배수를 가로로 출력하기.
		
		int n = 48; //제어변수.
		while(n <= 150) { //논리형 조건식.
			if(n % 8 == 0) {
				System.out.print(n + " ");
			}
			n++; //증감식.
		}
		System.out.println(); //단순 줄 개행
		
		int m = 48;
		while(m <= 150) {
			System.out.print(m + " ");
			m += 8;
		}
		
		System.out.println();
		//13~200까지의 정수 중 4의 배수이면서 8의 배수는 아닌 수만
		//가로로 출력해 보세요.
		
		int j = 13;
		while(j <= 200) {
			if(j % 4 == 0 && j % 8 != 0) {
				System.out.print(j + " ");
			}
			j++;
		}
		
		System.out.println();
		
		//1~20000까지의 정수 중 248의 배수의 갯수를 출력.
		
		int k = 1;
		int count = 0;
		
		while(k <= 20000) {
			if(k % 248 == 0) {
				count++;
			}
			k++;
		}
		
		System.out.println("1~20000중 248의 배수의 갯수: " + count);
		
		
		
		
		

	}

}
