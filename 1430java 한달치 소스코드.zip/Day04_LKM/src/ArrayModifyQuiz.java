import java.util.Arrays;
import java.util.Scanner;

public class ArrayModifyQuiz {

	public static void main(String[] args) {
		
		String[] kakao = {"무지", "라이언", "어피치", "제이지", "튜브"};
		
		/*
		 - 스캐너 객체를 생성해서 변경하고픈 별명을 입력받은 뒤
		  해당 값의 인덱스 번호를 찾아서 변경 값을 다시 입력받고
		  해당 변경 값으로 기존 인덱스의 값을 변경해 주세요.
		 */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("*변경 전 정보: " + Arrays.toString(kakao));
		System.out.println("수정할 멤버의 이름을 입력하세요.");
		System.out.print("> ");
		String name = sc.next();
		
		int idx;
		for(idx=0; idx<kakao.length; idx++) {
			if(name.equals(kakao[idx])) {
				System.out.println(kakao[idx] + "의 이름을 변경합니다.");
				System.out.print("> ");
				kakao[idx] = sc.next();
				System.out.println("변경 완료!");
				System.out.println("*변경 후 정보: " + Arrays.toString(kakao));
				break;
			}
		}
		
		if(idx == kakao.length) {
			System.out.println("해당 이름은 존재하지 않습니다.");
		}
		
		sc.close();
		
		
		
		

	}

}
