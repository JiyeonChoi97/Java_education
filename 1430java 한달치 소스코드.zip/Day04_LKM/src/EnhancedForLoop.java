
public class EnhancedForLoop {

	public static void main(String[] args) {
		
		String[] week = {"월","화","수","목","금","토","일"};
		
//		for(int idx=0; idx<week.length; idx++) {
//			System.out.println(week[idx] + "요일");
//		}
		
		for(String day : week) {
			System.out.println(day + "요일");
		}
		
		System.out.println("--------------------------");
		
		/*
		 1. scores라는 int배열에 점수 데이터를 저장하세요.
		 ex) [98, 71, 85, 66, 100, 95]
		 2. 향상된 for문을 사용하여 총점과 평균을 출력하세요.
		 3. 평균은 double 타입입니다. 소수점 둘째자리까지 출력하세요.
		 */
		
		int[] scores = {98, 71, 85, 66, 100, 95};
		
		int total = 0;
		for(int s : scores) {
			total += s;
		}
		
		double avg = (double)total / scores.length;
		System.out.printf("총점: %d점, 평균: %.2f점"
				, total, avg);
		
		
		
		
		
		
		
		
		
		

	}

}
