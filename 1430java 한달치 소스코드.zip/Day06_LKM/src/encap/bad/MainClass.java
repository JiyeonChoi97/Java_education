package encap.bad;

public class MainClass {

	public static void main(String[] args) {
		
		MyBirth my = new MyBirth();
		
		my.year = -200051;
		my.month = 999;
		my.day = 10352;
		
		my.birthInfo();
		
		
		
		
		

	}

}
