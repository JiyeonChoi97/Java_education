package encap.bad;

public class MyBirth {
	
	int year;
	int month;
	int day;
	
	void birthInfo() {
		System.out.printf("내 생일은 %d년 %d월 %d일입니다."
				 , this.year, this.month, this.day);
	}

}
