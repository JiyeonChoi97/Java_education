package modi.cls.pac1;

//public 제한자는 접근 제한이 없는 형태(어디에서나 접근, 사용이 가능)
public class B {
	
	A a = new A(); //package friendly는 같은 패키지 내에서
					//접근을 허용합니다.

}
