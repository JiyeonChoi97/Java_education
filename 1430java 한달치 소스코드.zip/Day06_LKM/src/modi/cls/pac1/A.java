package modi.cls.pac1;

/*
 - package friendly(default)제한자는 접근 제한자를 붙이지 않은
  형태이며, 같은 패키지 내에서만 접근을 허용합니다.
 */

class A {
	
	B b = new B(); //public

}
