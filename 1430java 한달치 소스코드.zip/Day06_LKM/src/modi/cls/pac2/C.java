package modi.cls.pac2;

import modi.cls.pac1.*;

public class C {
	
//	A a = new A(); //p.f는 외부 패키지에서 접근이 불가능합니다.
	B b = new B(); //public

}
