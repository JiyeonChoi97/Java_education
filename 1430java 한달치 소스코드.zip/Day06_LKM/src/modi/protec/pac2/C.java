package modi.protec.pac2;

import modi.protec.pac1.A;

public class C {
	
//	A a1 = new A(30); //protected (x)
//	A a2 = new A(3.14); //p.f (x)
	
	/*
	 - 상속관계가 없을 시 protected 접근 제한자는
	 p.f와 마찬가지로 같은 패키지 내에서만 접근을 허용합니다.
	 */
	
	
//	a1.x
	
	

}
