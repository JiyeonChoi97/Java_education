package modi.protec.pac1;

public class A {
	
	protected int x;
	int y; //p.f
	
	protected A(int i) {}
	A(double d) {}
	
	protected void method1() {}
	void method2() {}

}
