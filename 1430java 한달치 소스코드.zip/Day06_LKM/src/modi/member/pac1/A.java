package modi.member.pac1;

public class A {
	
	public int x;
	int y; // p.f
	private int z;
	
	public void method1() {}
	void method2() {}
	private void method3() {}
	
	
	public A() {
		
		x = 1;
		y = 2;
		z = 3;
		
		method1();
		method2();
		method3();
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
