package modi.constructor.pac1;

public class B {
	
	A a1 = new A(false); //public
	A a2 = new A(10); //p.f
//	A a3 = new A(5.5); //private(x)

}
