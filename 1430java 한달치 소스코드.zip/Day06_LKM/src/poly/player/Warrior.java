package poly.player;

public class Warrior extends Player {
	
	int rage;
	
	Warrior(String name) {
		super(name);
		this.rage = 60;
	}
	
	
	@Override 
	void characterInfo() {
		super.characterInfo();
		System.out.println("# 분노: " + rage);
	}

	
	void rush() {
		System.out.println(name + "님이 돌진 스킬을 시전합니다!");
	}
	
	

}








