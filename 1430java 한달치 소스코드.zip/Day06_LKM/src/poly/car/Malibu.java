package poly.car;

public class Malibu extends Car {

	@Override
	public void run() {
		System.out.println("말리부가 달립니다~");
	}

	
	
}
