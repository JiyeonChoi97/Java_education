package poly.car;

public class Sonata extends Car {

	@Override
	public void run() {
		System.out.println("소나타가 달립니다~");
	}
	
	

}
