package poly.car;

public class Htire extends Tire {
	
	public Htire() {
		System.out.println("한국타이어로 교체!");
	}

}
