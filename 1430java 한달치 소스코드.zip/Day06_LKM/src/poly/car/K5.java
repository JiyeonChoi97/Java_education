package poly.car;

public class K5 extends Car {

	@Override
	public void run() {
		System.out.println("K5가 달립니다~");
	}
	
	

}
