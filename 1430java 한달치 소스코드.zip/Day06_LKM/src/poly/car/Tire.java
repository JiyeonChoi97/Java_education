package poly.car;

public class Tire {

}
