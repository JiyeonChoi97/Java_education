package poly.car;

public class Car {
	
	Tire frontLeft;
	Tire frontRight;
	Tire rearLeft;
	Tire rearRight;
	

	
	public void run() {
		System.out.println("자동차가 달립니다~");
	}

}
