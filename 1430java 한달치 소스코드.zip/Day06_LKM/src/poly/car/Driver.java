package poly.car;

public class Driver {
	
//	void drive(Sonata s) {
//		s.run();
//	}
//	
//	void drive(K5 k) {
//		k.run();
//	}
	
	
	void drive(Car c) {
		c.run();
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
