package poly.car;

public class Ntire extends Tire {
	
	public Ntire() {
		System.out.println("넥센타이어로 교체!");
	}

}
