package api.lang.stringbuilder;

public class StrTest {

	public static void main(String[] args) {
		
		//String 속도체크
		long start, end;
		
		start = System.currentTimeMillis();
		
		String str = "A";
		
		for(int i=0; i < 200000; i++) 
			str = str + "A";
		
		end = System.currentTimeMillis();
		System.out.println("String 실행 시간: "
				+ (end - start) * 0.001 + "초");
		
		//StringBuilder 속도 체크
		start = System.currentTimeMillis();
		
		StringBuilder sb = new StringBuilder("A");
		
		for(int i=0; i < 200000; i++)
			sb.append("A");
		end = System.currentTimeMillis();
		
		System.out.println("StringBuilder 실행 시간: "
				+ (end - start) * 0.001 + "초");

	}

}




