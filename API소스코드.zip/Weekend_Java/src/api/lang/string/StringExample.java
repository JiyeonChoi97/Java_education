package api.lang.string;

import java.util.Arrays;

public class StringExample {

	public static void main(String[] args) {
		
		String s1 = "hello java";
		
		//charAt(index): 문자열의 특정 인덱스의 문자값을 리턴.
		char c = s1.charAt(4);
		System.out.println("4번 인덱스 문자값: " + c);
		
		//substring(index): 문자열의 특정 범위의 문자를 추출.
		String s2 = s1.substring(6);//6번부터 끝까지 추출.
		System.out.println(s2);
		
		//0번부터 5번 미만까지 추출.
		System.out.println(s1.substring(0, 5));
		
		//length(): 문자열의 총 길이를 리턴.
		int len = s1.length();
		System.out.println("s1의 총 문자개수: " + len);
		
		//indexOf(문자열): 특정 단어의 인덱스를 리턴.
		// 단어를 검색하면 해당 단어의 첫 글자를 리턴, 찾는 단어가 없다면 
		// -1을 리턴.
		int idx = s1.indexOf("o");
		System.out.println("o의 인덱스: " + idx);
		
		idx = s1.indexOf("java");
		System.out.println("java의 첫글자 인덱스: " + idx);
		
		idx = s1.indexOf("메렁메렁");
		System.out.println(idx);
		
		//toLowerCase(), toUpperCase()
		//문자열을 각각 소문자, 대문자로 일괄 변경.
		String s4 = "Hello MY WorlD!";
		System.out.println(s4.toLowerCase());
		System.out.println(s4.toUpperCase());
		
		//trim(): 문자열의 앞 뒤 공백을 제거.
		String name = "     최영희      ";
		System.out.println(name.trim() + "님 안녕하세요~~!");
		
		//replace(old, new)
		//문자열 내부에 old문자열을 모두 찾아 new문자열로 일괄 대체.
		String java = "java study, java program, java coffee";
		System.out.println(java.replace("java", "자바"));
		System.out.println(java.replace("java", ""));
		
		//split(구분문자열)
		//문자열을 구분문자열 기준으로 분리하여 String배열로 리턴.
		String pet = "멍멍이 야옹이 어흥이";
		String[] pets = pet.split(" ");
		System.out.println(Arrays.toString(pets));
		
		String tvxq = "영웅재중, 시아준수, 믹키유천, 최강창민, 유노윤호";
		System.out.println(Arrays.toString(tvxq.split(", ")));
	}

}




