package api.lang.string;

import java.util.Scanner;

public class StringQuiz {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.print("주민번호: ");
		String ssn = sc.next();
		System.out.println("앞자리: " + ssn.substring(0, 6));
		System.out.println("뒷자리: " + ssn.substring(7));
		
		int year = Integer.parseInt(ssn.substring(0, 2));
		int month = Integer.parseInt(ssn.substring(2, 4));
		int day = Integer.parseInt(ssn.substring(4, 6));
				
		String gender = null;
		int age = 0;
		int birthYear = 0;
		
		if(ssn.charAt(7) == '1' || ssn.charAt(7) == '3') {
			gender = "남자";
		} else {
			gender = "여자";
		}		
		if(ssn.charAt(7) == '1' || ssn.charAt(7) == '2') {
			birthYear = 1900 + year;
			age = 2019 - birthYear + 1;
		} else {
			birthYear = 2000 + year;
			age = 2019 - birthYear + 1;
		}
		System.out.printf("%d년도 %d월 %d일생 %d세 %s", 
			      birthYear, month, day, age, gender);
		
		sc.close();
		
	}

}




