package api.util.arrays;

import java.util.Arrays;

public class ArraysExample {

	public static void main(String[] args) {
		
		//배열의 복사
		char[] arr1 = {'J', 'A', 'V', 'A'};
		char[] arr2 = Arrays.copyOf(arr1, arr1.length);
		char[] arr3 = Arrays.copyOfRange(arr1, 1, 3);
//		arr2[2] = 'F';
		
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		System.out.println(Arrays.toString(arr3));
		
		//배열 탐색.
		String[] foods = {"닭강정", "김말이", "단무지", "떡볶이"};
		
		int idx = Arrays.binarySearch(foods, "단무지");
		System.out.println("단무지가 저장된 인덱스: " + idx);
		
		//배열 정렬.
		Arrays.sort(foods); //오름차 정렬
		System.out.println(Arrays.toString(foods));
		
		//배열 값 비교
		String[] foods2 = Arrays.copyOf(foods, foods.length);
		
		foods[0] = "짜장면";
		System.out.println(Arrays.equals(foods, foods2));

	}

}



