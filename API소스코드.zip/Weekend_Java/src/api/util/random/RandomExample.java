package api.util.random;

import java.util.Random;

public class RandomExample {

	public static void main(String[] args) {
		
		Random r = new Random();
		
		//실수 난수값 발생: 0.0 <= ~ < 1.0
		double d = r.nextDouble();
		System.out.println("실수 랜덤값: " + d);
		
		//정수 랜덤값 발생.
		int i = r.nextInt(6); //0이상 6미만의 난수(0~5)
		System.out.println("i의 값: " + i);
		
		int j = r.nextInt(10) + 1;
		System.out.println("j의 값: " + j);

	}

}
